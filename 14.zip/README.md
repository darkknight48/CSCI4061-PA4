# Project #4 - Network Sockets
* csel-kh1250-14
* G14, Andrew Bianchini, Charlie Nazarian, Graham Pearson
* bianc064, nazar077, pear0711
* Whether to complete the extra task: TBD
* Andrew: Protocol, Charlie: Server, Graham: Client
* Any assumptions outside this document - Assume there are substantial waits between runs of the program (otherwise socket fails to bind for the server if you go again too quickly)
* How to compile and run your program
* make, ./server, ./client
