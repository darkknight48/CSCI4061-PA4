#ifndef CLIENT_H
#define CLIENT_H

#include "utils.h"

void printSyntax();

#endif
