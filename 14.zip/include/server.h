#ifndef SERVER_H
#define SERVER_H

#include "utils.h"

void printSyntax();

#endif

